// server/models.go
package common

import (
	"encoding/json"
	"net"
	"os"
)

// User represents a player account
type User struct {
	Username     string         `json:"username"`
	PasswordHash string         `json:"password_hash"`
	Level        int            `json:"level"`
	EXP          int            `json:"exp"`
	TroopLevels  map[string]int `json:"troop_levels"`
	TowerLevels  map[string]int `json:"tower_levels"`
}

// // Player represents a game player
type Player struct {
	Username string
	Password string
	Mana     int
	Towers   []*Tower
	Conn     net.Conn
}

// // Tower represents a game tower
type Tower struct {
	Name string
	HP   int
	DEF  int
}

// TroopSpec loaded from specs.json
type TroopSpec struct {
	HP   int `json:"hp"`
	ATK  int `json:"atk"`
	DEF  int `json:"def"`
	Mana int `json:"mana"`
	EXP  int `json:"exp"`
}

// TowerSpec loaded from specs.json
type TowerSpec struct {
	HP   int     `json:"hp"`
	ATK  int     `json:"atk"`
	DEF  int     `json:"def"`
	Crit float64 `json:"crit"`
	EXP  int     `json:"exp"`
}

// PDU is the envelope for all messages (newline‑delimited JSON)
type PDU struct {
	Type string          `json:"type"`
	Data json.RawMessage `json:"data"`
}

// LoadUsers reads the users JSON file
func LoadUsers(path string) (map[string]User, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var users map[string]User
	if err := json.NewDecoder(file).Decode(&users); err != nil {
		return nil, err
	}
	return users, nil
}

// SaveUsers writes the user map back to JSON file
func SaveUsers(path string, m map[string]User) error {
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	enc := json.NewEncoder(file)
	enc.SetIndent("", "  ")
	return enc.Encode(m)
}

// LoadSpecs reads unit specifications (troops and towers) from a JSON file
// into the provided maps. Returns error on failure.
func LoadSpecs(path string, troops map[string]TroopSpec, towers map[string]TowerSpec) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()
	var raw struct {
		Troops map[string]TroopSpec `json:"troops"`
		Towers map[string]TowerSpec `json:"towers"`
	}
	dec := json.NewDecoder(file)
	if err := dec.Decode(&raw); err != nil {
		return err
	}
	// copy into provided maps
	for k, v := range raw.Troops {
		troops[k] = v
	}
	for k, v := range raw.Towers {
		towers[k] = v
	}
	return nil
}
